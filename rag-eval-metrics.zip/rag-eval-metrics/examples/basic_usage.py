from rag_eval_metrics import RAGEvaluator

evaluator = RAGEvaluator()

result = evaluator.evaluate(
    question="What is retrieval-augmented generation?",
    answer="RAG is a technique that combines information retrieval with text generation to produce more accurate and grounded responses from language models.",
    contexts=[
        "Retrieval-Augmented Generation (RAG) enhances LLM outputs by retrieving relevant documents from a knowledge base before generating responses.",
        "RAG pipelines typically consist of a retriever component and a generator component working together.",
    ],
    ground_truth="RAG combines retrieval with generation to improve LLM accuracy.",
)

print("Individual Scores:")
print(f"  Faithfulness:       {result.faithfulness:.4f}")
print(f"  Relevancy:          {result.relevancy:.4f}")
print(f"  Context Precision:  {result.context_precision:.4f}")
print(f"  Context Recall:     {result.context_recall:.4f}")
print(f"  Overall:            {result.overall:.4f}")

dataset = [
    {
        "question": "What is a vector database?",
        "answer": "A vector database stores high-dimensional embeddings for similarity search.",
        "contexts": ["Vector databases like Pinecone and Weaviate store embeddings for fast nearest-neighbor lookup."],
        "ground_truth": "Vector databases store embeddings for similarity search.",
    },
    {
        "question": "What is chunking in RAG?",
        "answer": "Chunking splits documents into smaller pieces for better retrieval.",
        "contexts": ["Document chunking strategies include fixed-size, semantic, and recursive splitting."],
        "ground_truth": "Chunking divides documents into smaller segments for retrieval.",
    },
]

batch_results = evaluator.evaluate_batch(dataset)
print("\nBatch Results:")
for k, v in batch_results.summary().items():
    print(f"  {k}: {v:.4f}" if isinstance(v, float) else f"  {k}: {v}")
