import pytest
from unittest.mock import MagicMock, patch
import numpy as np


class MockEmbeddingModel:
    def encode(self, texts):
        if isinstance(texts, str):
            texts = [texts]
        return np.random.randn(len(texts), 384).astype(np.float32)

    def similarity(self, text1, text2):
        return 0.85

    def batch_similarity(self, text, candidates):
        return [0.85] * len(candidates)


@pytest.fixture
def mock_embed():
    return MockEmbeddingModel()


class TestFaithfulness:
    def test_empty_answer(self, mock_embed):
        from rag_eval_metrics.metrics.faithfulness import faithfulness
        assert faithfulness("", ["context"], mock_embed) == 0.0

    def test_empty_contexts(self, mock_embed):
        from rag_eval_metrics.metrics.faithfulness import faithfulness
        assert faithfulness("answer", [], mock_embed) == 0.0

    def test_faithful_answer(self, mock_embed):
        from rag_eval_metrics.metrics.faithfulness import faithfulness
        score = faithfulness(
            "Paris is the capital of France. It is a beautiful city.",
            ["Paris is the capital and most populous city of France."],
            mock_embed,
        )
        assert 0.0 <= score <= 1.0

    def test_threshold(self, mock_embed):
        from rag_eval_metrics.metrics.faithfulness import faithfulness
        score = faithfulness(
            "This is a test sentence.",
            ["Some context here."],
            mock_embed,
            threshold=0.9,
        )
        assert 0.0 <= score <= 1.0


class TestRelevancy:
    def test_empty_inputs(self, mock_embed):
        from rag_eval_metrics.metrics.relevancy import relevancy
        assert relevancy("", "answer", mock_embed) == 0.0
        assert relevancy("question", "", mock_embed) == 0.0

    def test_relevant_answer(self, mock_embed):
        from rag_eval_metrics.metrics.relevancy import relevancy
        score = relevancy("What is AI?", "AI is artificial intelligence.", mock_embed)
        assert 0.0 <= score <= 1.0


class TestContextPrecision:
    def test_empty_contexts(self, mock_embed):
        from rag_eval_metrics.metrics.context_precision import context_precision
        assert context_precision("q", [], "gt", mock_embed) == 0.0

    def test_precision_score(self, mock_embed):
        from rag_eval_metrics.metrics.context_precision import context_precision
        score = context_precision(
            "What is ML?",
            ["ML is machine learning.", "Unrelated text.", "ML uses algorithms."],
            "Machine learning",
            mock_embed,
        )
        assert 0.0 <= score <= 1.0


class TestContextRecall:
    def test_empty_inputs(self, mock_embed):
        from rag_eval_metrics.metrics.context_recall import context_recall
        assert context_recall([], "gt", mock_embed) == 0.0
        assert context_recall(["ctx"], "", mock_embed) == 0.0

    def test_recall_score(self, mock_embed):
        from rag_eval_metrics.metrics.context_recall import context_recall
        score = context_recall(
            ["Paris is the capital of France."],
            "Paris is the capital of France.",
            mock_embed,
        )
        assert 0.0 <= score <= 1.0


class TestRAGEvaluator:
    @patch("rag_eval_metrics.evaluator.EmbeddingModel")
    def test_evaluate(self, MockEmbed):
        MockEmbed.return_value = MockEmbeddingModel()
        from rag_eval_metrics.evaluator import RAGEvaluator
        evaluator = RAGEvaluator()
        result = evaluator.evaluate(
            question="What is AI?",
            answer="AI is artificial intelligence.",
            contexts=["AI stands for artificial intelligence."],
            ground_truth="Artificial intelligence",
        )
        assert hasattr(result, "faithfulness")
        assert hasattr(result, "relevancy")
        assert hasattr(result, "context_precision")
        assert hasattr(result, "context_recall")
        assert 0.0 <= result.overall <= 1.0

    @patch("rag_eval_metrics.evaluator.EmbeddingModel")
    def test_batch_evaluate(self, MockEmbed):
        MockEmbed.return_value = MockEmbeddingModel()
        from rag_eval_metrics.evaluator import RAGEvaluator
        evaluator = RAGEvaluator()
        dataset = [
            {"question": "Q1", "answer": "A1", "contexts": ["C1"], "ground_truth": "GT1"},
            {"question": "Q2", "answer": "A2", "contexts": ["C2"], "ground_truth": "GT2"},
        ]
        results = evaluator.evaluate_batch(dataset)
        summary = results.summary()
        assert summary["num_samples"] == 2
