# RAG Evaluation Metrics

[![PyPI version](https://badge.fury.io/py/rag-eval-metrics.svg)](https://pypi.org/project/rag-eval-metrics/)
[![Downloads](https://pepy.tech/badge/rag-eval-metrics/month)](https://pepy.tech/project/rag-eval-metrics)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

A Python package for evaluating Retrieval-Augmented Generation (RAG) pipelines. Measures **faithfulness**, **relevancy**, **context precision**, and **context recall** — the four pillars of RAG quality.

Also an active contributor to the **LangChain ecosystem** — submitted PRs for retriever optimizations and chunking strategies.

## Installation

```bash
pip install rag-eval-metrics
```

## Quick Start

```python
from rag_eval_metrics import RAGEvaluator

evaluator = RAGEvaluator()

result = evaluator.evaluate(
    question="What is the capital of France?",
    answer="The capital of France is Paris.",
    contexts=["Paris is the capital and most populous city of France."],
    ground_truth="Paris"
)

print(result)
# {'faithfulness': 1.0, 'relevancy': 0.95, 'context_precision': 0.92, 'context_recall': 1.0}
```

## Metrics

| Metric | What it Measures | Range |
|--------|-----------------|-------|
| **Faithfulness** | Is the answer grounded in the retrieved context? | 0.0 - 1.0 |
| **Relevancy** | Is the answer relevant to the question? | 0.0 - 1.0 |
| **Context Precision** | Are the retrieved contexts precise and useful? | 0.0 - 1.0 |
| **Context Recall** | Do the contexts cover the ground truth? | 0.0 - 1.0 |

## Detailed Usage

### Individual Metrics

```python
from rag_eval_metrics import faithfulness, relevancy, context_precision, context_recall

score = faithfulness(
    answer="Paris is the capital of France.",
    contexts=["Paris is the capital and most populous city of France."]
)

score = relevancy(
    question="What is the capital of France?",
    answer="The capital of France is Paris."
)

score = context_precision(
    question="What is the capital of France?",
    contexts=["Paris is the capital of France.", "France is in Europe.", "The Eiffel Tower is in Paris."],
    ground_truth="Paris"
)

score = context_recall(
    contexts=["Paris is the capital and most populous city of France."],
    ground_truth="Paris is the capital of France."
)
```

### Batch Evaluation

```python
from rag_eval_metrics import RAGEvaluator

evaluator = RAGEvaluator()

dataset = [
    {
        "question": "What is RAG?",
        "answer": "RAG stands for Retrieval-Augmented Generation.",
        "contexts": ["RAG combines retrieval with generation for better LLM responses."],
        "ground_truth": "Retrieval-Augmented Generation"
    },
    # ... more samples
]

results = evaluator.evaluate_batch(dataset)
print(results.summary())
```

### Custom Embedding Model

```python
evaluator = RAGEvaluator(
    embedding_model="sentence-transformers/all-MiniLM-L6-v2",
    similarity_threshold=0.7,
)
```

### Integration with LangChain

```python
from rag_eval_metrics.integrations import LangChainEvaluator

evaluator = LangChainEvaluator(chain=my_rag_chain)
results = evaluator.evaluate_chain(test_questions, ground_truths)
```

## CLI

```bash
rag-eval --input test_data.jsonl --output results.json --metrics all
rag-eval --input test_data.jsonl --metrics faithfulness,relevancy
```

## Contributing

PRs welcome! See [CONTRIBUTING.md](CONTRIBUTING.md).

## License

MIT
