# Contributing to RAG Eval Metrics

## Setup

```bash
git clone https://github.com/yourusername/rag-eval-metrics.git
cd rag-eval-metrics
pip install -e ".[dev]"
```

## Running Tests

```bash
pytest tests/ -v --cov=rag_eval_metrics
```

## Code Style

```bash
black rag_eval_metrics/ tests/
ruff check rag_eval_metrics/ tests/
```

## Adding a New Metric

1. Create `rag_eval_metrics/metrics/your_metric.py`
2. Add to `rag_eval_metrics/metrics/__init__.py`
3. Add to `RAGEvaluator` in `evaluator.py`
4. Add tests in `tests/test_metrics.py`
5. Update README

## Pull Request Process

1. Fork the repo
2. Create a feature branch
3. Write tests
4. Ensure all tests pass
5. Submit PR with description of changes
