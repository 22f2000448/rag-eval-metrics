import json
import argparse
import sys
from .evaluator import RAGEvaluator


def main():
    parser = argparse.ArgumentParser(prog="rag-eval", description="RAG Evaluation Metrics CLI")
    parser.add_argument("--input", required=True, help="Input JSONL file")
    parser.add_argument("--output", default="results.json", help="Output JSON file")
    parser.add_argument("--metrics", default="all", help="Comma-separated metrics or 'all'")
    parser.add_argument("--model", default="sentence-transformers/all-MiniLM-L6-v2")
    parser.add_argument("--threshold", type=float, default=0.7)
    parser.add_argument("--gpu", action="store_true")
    args = parser.parse_args()

    dataset = []
    with open(args.input) as f:
        for line in f:
            dataset.append(json.loads(line.strip()))

    evaluator = RAGEvaluator(
        embedding_model=args.model,
        similarity_threshold=args.threshold,
        use_gpu=args.gpu,
    )

    results = evaluator.evaluate_batch(dataset)
    summary = results.summary()

    output = {
        "summary": summary,
        "results": [r.to_dict() for r in results.results],
    }

    with open(args.output, "w") as f:
        json.dump(output, f, indent=2)

    print(f"Evaluation complete. {summary['num_samples']} samples evaluated.")
    for k, v in summary.items():
        if k != "num_samples":
            print(f"  {k}: {v:.4f}")
    print(f"Results saved to {args.output}")


if __name__ == "__main__":
    main()
