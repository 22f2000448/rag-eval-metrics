import logging
from typing import Optional
from dataclasses import dataclass, field
from .metrics.faithfulness import faithfulness
from .metrics.relevancy import relevancy
from .metrics.context_precision import context_precision
from .metrics.context_recall import context_recall
from .embeddings import EmbeddingModel

logger = logging.getLogger(__name__)


@dataclass
class EvalResult:
    faithfulness: float
    relevancy: float
    context_precision: float
    context_recall: float

    def to_dict(self) -> dict:
        return {
            "faithfulness": self.faithfulness,
            "relevancy": self.relevancy,
            "context_precision": self.context_precision,
            "context_recall": self.context_recall,
        }

    @property
    def overall(self) -> float:
        return (self.faithfulness + self.relevancy + self.context_precision + self.context_recall) / 4


@dataclass
class BatchResult:
    results: list[EvalResult] = field(default_factory=list)

    def summary(self) -> dict:
        if not self.results:
            return {}
        n = len(self.results)
        return {
            "num_samples": n,
            "avg_faithfulness": sum(r.faithfulness for r in self.results) / n,
            "avg_relevancy": sum(r.relevancy for r in self.results) / n,
            "avg_context_precision": sum(r.context_precision for r in self.results) / n,
            "avg_context_recall": sum(r.context_recall for r in self.results) / n,
            "avg_overall": sum(r.overall for r in self.results) / n,
        }


class RAGEvaluator:
    def __init__(
        self,
        embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2",
        similarity_threshold: float = 0.7,
        use_gpu: bool = False,
    ):
        self.embed_model = EmbeddingModel(embedding_model, use_gpu=use_gpu)
        self.similarity_threshold = similarity_threshold

    def evaluate(
        self,
        question: str,
        answer: str,
        contexts: list[str],
        ground_truth: Optional[str] = None,
    ) -> EvalResult:
        faith_score = faithfulness(answer, contexts, self.embed_model, self.similarity_threshold)
        rel_score = relevancy(question, answer, self.embed_model)
        prec_score = context_precision(question, contexts, ground_truth, self.embed_model) if ground_truth else 0.0
        recall_score = context_recall(contexts, ground_truth, self.embed_model) if ground_truth else 0.0

        return EvalResult(
            faithfulness=faith_score,
            relevancy=rel_score,
            context_precision=prec_score,
            context_recall=recall_score,
        )

    def evaluate_batch(self, dataset: list[dict]) -> BatchResult:
        batch = BatchResult()
        for i, sample in enumerate(dataset):
            result = self.evaluate(
                question=sample["question"],
                answer=sample["answer"],
                contexts=sample["contexts"],
                ground_truth=sample.get("ground_truth"),
            )
            batch.results.append(result)
            if (i + 1) % 50 == 0:
                logger.info(f"Evaluated {i+1}/{len(dataset)}")
        return batch
