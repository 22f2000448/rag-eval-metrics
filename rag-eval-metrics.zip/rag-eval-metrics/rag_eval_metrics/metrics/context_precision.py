import numpy as np
from typing import Optional
from ..embeddings import EmbeddingModel


def context_precision(
    question: str,
    contexts: list[str],
    ground_truth: str,
    embed_model: Optional[EmbeddingModel] = None,
) -> float:
    if not contexts or not ground_truth:
        return 0.0

    if embed_model is None:
        embed_model = EmbeddingModel()

    gt_emb = embed_model.encode(ground_truth)
    ctx_embs = embed_model.encode(contexts)

    similarities = np.dot(ctx_embs, gt_emb[0])
    ranked_indices = np.argsort(-similarities)

    precision_at_k = []
    relevant_count = 0

    for k, idx in enumerate(ranked_indices, 1):
        if similarities[idx] >= 0.5:
            relevant_count += 1
            precision_at_k.append(relevant_count / k)

    if not precision_at_k:
        return 0.0

    return sum(precision_at_k) / len(contexts)
