import re
import numpy as np
from typing import Optional
from ..embeddings import EmbeddingModel


def faithfulness(
    answer: str,
    contexts: list[str],
    embed_model: Optional[EmbeddingModel] = None,
    threshold: float = 0.7,
) -> float:
    if not answer or not contexts:
        return 0.0

    if embed_model is None:
        embed_model = EmbeddingModel()

    claims = _extract_claims(answer)
    if not claims:
        return 0.0

    context_combined = " ".join(contexts)
    supported = 0

    for claim in claims:
        sim = embed_model.similarity(claim, context_combined)
        if sim >= threshold:
            supported += 1

    return supported / len(claims)


def _extract_claims(text: str) -> list[str]:
    sentences = re.split(r'(?<=[.!?])\s+', text.strip())
    claims = [s.strip() for s in sentences if len(s.strip().split()) >= 3]
    return claims
