from typing import Optional
from ..embeddings import EmbeddingModel


def relevancy(
    question: str,
    answer: str,
    embed_model: Optional[EmbeddingModel] = None,
) -> float:
    if not question or not answer:
        return 0.0

    if embed_model is None:
        embed_model = EmbeddingModel()

    sim = embed_model.similarity(question, answer)
    return max(0.0, min(1.0, sim))
