import re
import numpy as np
from typing import Optional
from ..embeddings import EmbeddingModel


def context_recall(
    contexts: list[str],
    ground_truth: str,
    embed_model: Optional[EmbeddingModel] = None,
    threshold: float = 0.6,
) -> float:
    if not contexts or not ground_truth:
        return 0.0

    if embed_model is None:
        embed_model = EmbeddingModel()

    gt_sentences = re.split(r'(?<=[.!?])\s+', ground_truth.strip())
    gt_sentences = [s.strip() for s in gt_sentences if len(s.strip().split()) >= 2]

    if not gt_sentences:
        return embed_model.similarity(ground_truth, " ".join(contexts))

    context_combined = " ".join(contexts)
    recalled = 0

    for sentence in gt_sentences:
        sim = embed_model.similarity(sentence, context_combined)
        if sim >= threshold:
            recalled += 1

    return recalled / len(gt_sentences)
