from ..evaluator import RAGEvaluator, BatchResult


class LangChainEvaluator:
    def __init__(self, chain=None, evaluator: RAGEvaluator = None):
        self.chain = chain
        self.evaluator = evaluator or RAGEvaluator()

    def evaluate_chain(
        self,
        questions: list[str],
        ground_truths: list[str],
    ) -> BatchResult:
        dataset = []
        for q, gt in zip(questions, ground_truths):
            response = self.chain.invoke({"query": q})
            answer = response.get("result", response.get("output", ""))
            contexts = [doc.page_content for doc in response.get("source_documents", [])]
            dataset.append({
                "question": q,
                "answer": answer,
                "contexts": contexts,
                "ground_truth": gt,
            })
        return self.evaluator.evaluate_batch(dataset)
