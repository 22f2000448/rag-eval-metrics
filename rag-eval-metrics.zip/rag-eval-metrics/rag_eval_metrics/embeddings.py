import numpy as np
from typing import Union


class EmbeddingModel:
    def __init__(self, model_name: str = "sentence-transformers/all-MiniLM-L6-v2", use_gpu: bool = False):
        from sentence_transformers import SentenceTransformer
        device = "cuda" if use_gpu else "cpu"
        self.model = SentenceTransformer(model_name, device=device)

    def encode(self, texts: Union[str, list[str]]) -> np.ndarray:
        if isinstance(texts, str):
            texts = [texts]
        return self.model.encode(texts, normalize_embeddings=True)

    def similarity(self, text1: str, text2: str) -> float:
        emb1 = self.encode(text1)
        emb2 = self.encode(text2)
        return float(np.dot(emb1[0], emb2[0]))

    def batch_similarity(self, text: str, candidates: list[str]) -> list[float]:
        text_emb = self.encode(text)
        cand_embs = self.encode(candidates)
        scores = np.dot(cand_embs, text_emb[0])
        return scores.tolist()
